export class FirebaseLoginModel {
  id: string;
  localId: string;
  email: string;
  displayName: string;
  idToken: string;
  registered: boolean;
  refreshToken: string;
  expires: string;
}
