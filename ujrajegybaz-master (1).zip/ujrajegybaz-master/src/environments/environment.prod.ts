export const environment = {
  production: false,
  firebase: {
    baseUrl: 'https://jegybazar-133bd.firebaseio.com/',
    registrationUrl: 'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key',
    loginUrl: 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key',
    apiKey: 'AIzaSyAuEmr6G2pHf3jU2FWTsuj07PvGERwO0Eo',
    authDomain: 'jegybazar-133bd.firebaseapp.com',
    databaseURL: 'https://jegybazar-133bd.firebaseio.com',
    projectId: 'jegybazar-133bd',
    storageBucket: 'jegybazar-133bd.appspot.com',
    messagingSenderId: '726633883296',
    appId: '1:726633883296:web:df8e7716544d9f6334cbc5',
    measurementId: 'G-VQDZYEXF7V'
  }
};
