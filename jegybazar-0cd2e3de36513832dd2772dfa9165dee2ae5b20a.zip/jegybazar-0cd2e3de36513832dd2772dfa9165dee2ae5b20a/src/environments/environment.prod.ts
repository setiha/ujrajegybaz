export const environment = {
  production: true,
  firebase: {
    baseUrl: 'https://jegybazar-27302.firebaseio.com',
    registrationUrl: ' https://www.googleapis.com/identitytoolkit/v3/relyingparty/signupNewUser',
    loginUrl: ' https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword',
    apiKey: 'AIzaSyALPBS-gllA6F-vRya-6pYZXABheOWFYlw',
    authDomain: 'jegybazar-27302.firebaseapp.com',
    databaseURL: 'https://jegybazar-27302.firebaseio.com',
    projectId: 'jegybazar-27302',
    storageBucket: 'jegybazar-27302.appspot.com',
    messagingSenderId: '873164960496'
  }
};
